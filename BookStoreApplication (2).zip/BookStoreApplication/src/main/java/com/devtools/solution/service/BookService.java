package com.devtools.solution.service;

import com.devtools.solution.DTO.BookDto;
import com.devtools.solution.entity.Book;
import com.devtools.solution.repo.BookDal;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    @Autowired
    BookDal bookDal;


    public void saveBook(BookDto bookDto){
        Book book= new Book();
        book.setAuthor(bookDto.getAuthor());
        book.setPrice(bookDto.getPrice());
book.setTitle(bookDto.getTitle());
book.setQuantity(book.getQuantity());
        bookDal.save(book);
    }
    public Book getBook(int id){
        return bookDal.findById(id).get();
    }

    public void deleteBook(int id) {
        bookDal.deleteById(id);
    }

    public List<Book> getAllBooks() {
    return bookDal.findAll();
    }
}
