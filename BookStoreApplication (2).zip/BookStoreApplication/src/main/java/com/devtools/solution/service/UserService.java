package com.devtools.solution.service;

import com.devtools.solution.entity.User;
import com.devtools.solution.repo.UserRepoInterface;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepoInterface userRepoInterface;

    public User getUser(int id){
        return userRepoInterface.findById(id).get();
    }

    public void saveUser(User user){
        userRepoInterface.save(user);
    }

    public void delete(int id){
        userRepoInterface.deleteById(id);
    }
}
