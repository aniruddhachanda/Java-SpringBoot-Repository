package com.codingninjas.EVotingSystem.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingninjas.EVotingSystem.entities.Election;
import com.codingninjas.EVotingSystem.entities.ElectionChoice;
import com.codingninjas.EVotingSystem.entities.User;
import com.codingninjas.EVotingSystem.entities.Vote;
import com.codingninjas.EVotingSystem.repositories.ElectionChoiceRepository;
import com.codingninjas.EVotingSystem.repositories.ElectionRepository;
import com.codingninjas.EVotingSystem.repositories.UserRepository;
import com.codingninjas.EVotingSystem.repositories.VoteRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class VoteService {

	@Autowired
	VoteRepository voteRepository;
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ElectionChoiceRepository electionChoiceRepository;
	
	@Autowired
	ElectionRepository electionRepository;
	
	public List<Vote> getAllVotes() {
		// TODO Auto-generated method stub
		return voteRepository.findAll();
	}

	public Long getTotalVotes() {
		// TODO Auto-generated method stub
		return voteRepository.getTotalVotes();
	}

	public Vote addVote(Vote vote) {
		// TODO Auto-generated method stub
		Vote updatedVote = new Vote();
		User user = userRepository.findUserByName(vote.getUser().getName());
		Election election = electionRepository.findElectionByName(vote.getElection().getName());
		ElectionChoice electionChoice = electionChoiceRepository.findElectionChoiceByNameAndElection(vote.getElectionChoice().getName(), election);
		updatedVote.setElection(election);
		updatedVote.setElectionChoice(electionChoice);
		updatedVote.setUser(user);
		return voteRepository.save(updatedVote);
	}

	public Long countTotalVoteByElection(Election election) {
		// TODO Auto-generated method stub
		Election updatedElection = electionRepository.findElectionByName(election.getName());
		return voteRepository.countTotalVoteByElection(updatedElection);
	}
	
	//added
	public Election findElectionByName(String electionName) {
		return electionRepository.findByName(electionName).orElseThrow();
	}
	
	public ElectionChoice findElectionChoiceWithMaxVotes(Election election) {
		return electionChoiceRepository.findElectionChoiceWithMaxVotes(election.getId());
	}
	
	public long countVotesByElection(Election election) {
		return voteRepository.countVotesByElection(election);
	}
	

}
