package com.codingninjas.EVotingSystem.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingninjas.EVotingSystem.entities.Election;
import com.codingninjas.EVotingSystem.repositories.ElectionRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ElectionService {
	
	@Autowired
	ElectionRepository electionRepository;

	public List<Election> getAllElections() {
		// TODO Auto-generated method stub
		return electionRepository.findAll() ;
	}

	public Election saveElection(Election election) {
		// TODO Auto-generated method stub
		return electionRepository.save(election);
	}

}
