package com.codingninjas.EVotingSystem.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.codingninjas.EVotingSystem.entities.Election;
import com.codingninjas.EVotingSystem.entities.ElectionChoice;
import com.codingninjas.EVotingSystem.services.ResultService;
import com.codingninjas.EVotingSystem.services.VoteService;
//import com.codingninjas.EVotingSystem.services.VotingService;

@RestController
public class ResultsController {

	@Autowired
	ResultService resultService;
	
	@Autowired
	VoteService votingService;

	
//	@PostMapping("/winner/election")
//	public ElectionChoice findElectionChoiceWithMaxVotes(@RequestBody Election election) {
//		return resultService.findElectionChoiceWithMaxVotes(election);
//	}
	
	@PostMapping("/winner/election")
	public ElectionChoice getWinnerOfElection(@RequestBody Election election) {
		Election updatedWinner = votingService.findElectionByName(election.getName());
		return votingService.findElectionChoiceWithMaxVotes(updatedWinner);
	}
	
}
