package com.codingninjas.EVotingSystem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.codingninjas.EVotingSystem.entities.Election;
import com.codingninjas.EVotingSystem.entities.Vote;
import com.codingninjas.EVotingSystem.services.VoteService;

@RestController
public class VoteController {

	@Autowired
	VoteService voteService;
	
	@GetMapping("/get/votes")
	public List<Vote> getAllVotes(){
		return voteService.getAllVotes();
	}
	
	@PostMapping("/add/vote")
	public Vote addVote(@RequestBody Vote vote) {
		return voteService.addVote(vote);
	}
	
	@GetMapping("/count/votes")
	public Long getTotatlVote() {
		return voteService.getTotalVotes();
	}
	
//	@GetMapping("/count/election/votes")
//	public Long countTotalVoteByElection(@RequestBody Election election) {
//		return voteService.countTotalVoteByElection(election);
//	}
	
	@PostMapping("/count/election/votes")
	public long getTotalNumberOfVotesByElection(@RequestBody Election election) {
		Election updatedElec = voteService.findElectionByName(election.getName());
		return voteService.countVotesByElection(updatedElec);
	}
	
}
