package com.codingninjas.EVotingSystem.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingninjas.EVotingSystem.entities.Election;
import com.codingninjas.EVotingSystem.entities.ElectionChoice;
import com.codingninjas.EVotingSystem.repositories.ElectionChoiceRepository;
import com.codingninjas.EVotingSystem.repositories.ElectionRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ResultService {

	@Autowired
	ElectionChoiceRepository electionChoiceRepository;
	
	@Autowired
	ElectionRepository electionRepository;
	
	public ElectionChoice findElectionChoiceWithMaxVotes(Election election) {
		// TODO Auto-generated method stub
		Election updatedWinner = electionRepository.findElectionByName(election.getName());
		ElectionChoice electionChoice = new ElectionChoice();
		electionChoice.setElection(updatedWinner);
		return electionChoiceRepository.findElectionChoiceWithMaxVotes(electionChoice.getId());
	}

}
