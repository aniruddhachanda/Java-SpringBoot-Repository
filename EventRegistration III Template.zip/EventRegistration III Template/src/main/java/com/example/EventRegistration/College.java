package com.example.EventRegistration;

public interface College {

    String getCollegeName();
    CollegeEvent getEvent();
}
