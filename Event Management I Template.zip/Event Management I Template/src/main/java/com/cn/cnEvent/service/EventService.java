package com.cn.cnEvent.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cn.cnEvent.dal.EventDAL;
import com.cn.cnEvent.entity.Event;

@Service
public class EventService {
	@Autowired
    private EventDAL eventDAL;

    @Transactional
    public Event getEventById(Long id) {
        return eventDAL.getById(id);
    }

    @Transactional
    public List<Event> getAllEvents() {
        return eventDAL.getAllEvents();
    }

    @Transactional
    public void saveEvent(Event event) {
        eventDAL.save(event);
    }
}
