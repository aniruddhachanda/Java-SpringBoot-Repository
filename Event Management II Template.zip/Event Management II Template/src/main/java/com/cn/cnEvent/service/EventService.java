package com.cn.cnEvent.service;

import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cn.cnEvent.dal.EventDAL;
import com.cn.cnEvent.entity.Event;

@Service
public class EventService {
	@Autowired
    private EventDAL eventDAL;

    @Transactional
    public Event getEventById(Long id) {
        return eventDAL.getById(id);
    }

    @Transactional
    public List<Event> getAllEvents() {
        List<Event> events=eventDAL.getAllEvents();
        if(events==null){

            throw new RuntimeException("No events found.");
        }
        return events;
    }

    @Transactional
    public void saveEvent(Event event) {
        eventDAL.save(event);
    }
    
    @Transactional
    public String deleteEvent(Long id) {
        List<Event> allEvents = getAllEvents();

        boolean isEntityPresent=false;
        for(Event event : allEvents)
        {
            if (Objects.equals(event.getId(), id)) {
                isEntityPresent = true;
            }
        }
        if(!isEntityPresent)
        {
            throw new RuntimeException("This event doesn't exist.");
        }
        try{
            return eventDAL.delete(id);
        }
        catch (Exception e){
            throw new RuntimeException("Error in deleting event.");
        }
    }

    @Transactional
    public String updateEvent(Event updateEvent) {
        try{
            return eventDAL.update(updateEvent);
        }
        catch (Exception e){
            throw new RuntimeException("Error in deleting eventScheduleDetail from event.");
        }
    }
}
