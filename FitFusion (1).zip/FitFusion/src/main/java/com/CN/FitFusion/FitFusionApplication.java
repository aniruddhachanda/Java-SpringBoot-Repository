package com.CN.FitFusion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FitFusionApplication {

	public static void main(String[] args) {
		SpringApplication.run(FitFusionApplication.class, args);
	}

}
