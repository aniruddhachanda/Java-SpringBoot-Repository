package com.CN.FitFusion.repository;

import com.CN.FitFusion.model.Diet;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DietRepository extends JpaRepository<Diet, Long> {

}
