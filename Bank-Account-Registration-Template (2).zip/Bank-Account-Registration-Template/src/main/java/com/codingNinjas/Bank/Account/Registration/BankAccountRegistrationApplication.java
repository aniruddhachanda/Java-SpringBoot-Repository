package com.codingNinjas.Bank.Account.Registration;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Scanner;

@SpringBootApplication
public class BankAccountRegistrationApplication {

	public static void main(String[] args) {

		/*
		You need to complete this application as mentioned in the problem 
		statement build your own logic and perform the following tasks.
		
		* 1. Fetch context from ApplicationContext.xml and initiate scanner.
		* 2. Get user details from console.
		* 3. Get account details from user and add them to the account list.
		* 4. Display the list of accounts with their reference ids.
		*/

		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Scanner sc=new Scanner(System.in);
		User user= (User) context.getBean("myUser");

		System.out.println("Welcome to Account Registration Application!");
		System.out.println("Please enter Your Name?");
		String name=sc.nextLine();
		user.setUserDetails(name);


		while(true){
			System.out.println("Do you want to add account\n1. Yes\n2. No");
			int choice=sc.nextInt();
			if(choice==2){
				break;
			}
			System.out.println("Please select the account type\n1. Current\n2. Saving");
			int secondchoice=sc.nextInt();
			String accountchoice=null;

			switch(secondchoice){
				case 1->{
					accountchoice="currentAccount";
					break;
				}
				case 2->{
					accountchoice="savingAccount";
					break;
				}
				default -> {
					return;
				}
			}
			
			Account account= (Account) context.getBean(accountchoice);
			System.out.println("Enter your Opening balance: ");
			double openingbalance=sc.nextDouble();

			account.addBalance(openingbalance);
			user.addAccount(account);
		}

		System.out.println("Hi "+user.getName()+", here is the list of your accounts: ");
		for (Account a: user.getAllAccounts()
			 ) {
			System.out.println(a.getAccountType()+ " : opening Balance - "+a.getBalance()+" Reference id: "+a.toString() );
		}

	}

}
