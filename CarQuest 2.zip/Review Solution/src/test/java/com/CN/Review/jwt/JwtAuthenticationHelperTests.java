package com.CN.Review.jwt;

import org.junit.jupiter.api.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import java.io.File;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

@SpringBootTest
@DisplayName("Testing JwtAuthenticationHelper class")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class JwtAuthenticationHelperTests {

    @Test
    @DisplayName("Testing JwtAuthenticationHelper File Existence")
    @Order(1)
    public void testFileExist(){
        String filePath = "src/main/java/com/CN/Review/jwt/JwtAuthenticationHelper.java";
        File file = new File(filePath);
        Assertions.assertTrue(file.exists(),"JwtAuthenticationHelper.java File don't exist");
    }

    @Test
    @DisplayName("Testing UserName Extraction after token generation")
    @Order(2)
    public void testGetUsernameFromToken() {
        JwtAuthenticationHelper jwtAuthenticationHelper = new JwtAuthenticationHelper();
        String username = "exampleUser";
        String token = generateToken(username);
        String extractedUsername = jwtAuthenticationHelper.getUsernameFromToken(token);
        assertEquals(username, extractedUsername);
    }

    @Test
    @DisplayName("Testing Token Expiry")
    @Order(3)
    public void testIsTokenExpired() {
        JwtAuthenticationHelper jwtAuthenticationHelper = new JwtAuthenticationHelper();
        String username = "exampleUser";
        String token = generateToken(username);
        boolean isExpired = jwtAuthenticationHelper.isTokenExpired(token);
        assertFalse(isExpired);
    }

    private String generateToken(String username) {
        GrantedAuthority authority = new SimpleGrantedAuthority("ROLE_USER");
        UserDetails userDetails = new User(username, "asd", Collections.singleton(authority));
        JwtAuthenticationHelper jwtAuthenticationHelper = new JwtAuthenticationHelper();
        return jwtAuthenticationHelper.generateToken(userDetails);
    }
}
