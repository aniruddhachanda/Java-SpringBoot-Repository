package com.CN.Review.config;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@DisplayName("Testing Config Layer")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ReviewSecurityConfigTests {

    @Test
    @Order(1)
    @DisplayName("Testing for JWT Dependencies")
    public void testDependencyPresence() throws IOException {

        String groupId = "io.jsonwebtoken";
        String artifactIdJwtApi = "jjwt-api";
        String artifactIdJwtImpl = "jjwt-impl";
        String artifactIdJwtJackson = "jjwt-jackson";

        Map<Integer,String> pomDependencyMap = new HashMap<>();
        pomDependencyMap.put(1,artifactIdJwtApi);
        pomDependencyMap.put(2,artifactIdJwtImpl);
        pomDependencyMap.put(3,artifactIdJwtJackson);

        StringBuilder pomContent = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader("pom.xml"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                pomContent.append(line);
            }
        }
        for(Map.Entry<Integer,String> entry : pomDependencyMap.entrySet()) {
            String regex = "<dependency>.*?<groupId>" + groupId + "</groupId>.*?<artifactId>" + entry.getValue() + "</artifactId>.*?</dependency>";
            Pattern pattern = Pattern.compile(regex, Pattern.DOTALL);
            Matcher matcher = pattern.matcher(pomContent);
            Assertions.assertTrue(matcher.find(), "Dependency with groupId: " + entry.getKey() + " & artifactId: "+ entry.getValue()+" is missing from pom.xml");
        }
    }

    @Test
    @DisplayName("Testing Auto-wires for ReviewSecurityConfig")
    @Order(2)
    void testAutowiredDependencies() throws IllegalAccessException {
        Field[] fields = ReviewSecurityConfig.class.getDeclaredFields();
        for (Field field : fields) {
            if (field.isAnnotationPresent(Autowired.class)) {
                String fieldClassName = field.getType().getSimpleName();
                Assertions.assertEquals("JwtAuthenticationFilter",fieldClassName);
            }
        }
    }

    @Test
    @DisplayName("Testing FilterChain Configurations")
    @Order(3)
    public void testIsTextPresentInFile() throws IOException {
        String filePath = "src/main/java/com/CN/Review/config/ReviewSecurityConfig.java";
        String searchText = "http.addFilterBefore(filter, UsernamePasswordAuthenticationFilter.class);";
        assertTrue(isTextPresentInFile(filePath, searchText));
    }


    public boolean isTextPresentInFile(String filePath, String searchText) throws IOException {
        boolean found = false;

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.contains(searchText)) {
                    found = true;
                    break;
                }
            }
        }

        return found;
    }

}
