package com.CN.Review.jwt;

import com.CN.Review.config.ReviewSecurityConfig;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@DisplayName("Testing JwtAuthenticationFilter class")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class JwtAuthenticationFilterTests {
    @Autowired
    private ReviewSecurityConfig storeSecurityConfig;

    @Test
    @DisplayName("Testing JwtAuthenticationFilter File Existence")
    @Order(1)
    public void testFileExist(){
        String filePath = "src/main/java/com/CN/Review/jwt/JwtAuthenticationFilter.java";
        File file = new File(filePath);
        assertTrue(file.exists(),"JwtAuthenticationFilter.java File don't exist");
    }

    @Test
    @DisplayName("Testing Auto-wire candidates for JwtAuthenticationFilter")
    @Order(2)
    void testAutowiredDependencies() {
        Field[] fields = JwtAuthenticationFilter.class.getDeclaredFields();
        List<String> autowireList = new ArrayList<>();
        for (Field field : fields) {
            if (field.isAnnotationPresent(Autowired.class)) {
                autowireList.add(field.getType().getSimpleName());
            }
        }
        boolean flag = (autowireList.contains("JwtAuthenticationHelper") && autowireList.contains("UserDetailsService"));
        Assertions.assertTrue(flag);
    }
}
